### R code from vignette source 'Non-iid-OkunevWhite.Rnw'

###################################################
### code chunk number 1: Non-iid-OkunevWhite.Rnw:46-48
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-OkunevWhite.Rnw:51-52
###################################################
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/Return.Okunev.R")


###################################################
### code chunk number 3: Graph10
###################################################
library(PerformanceAnalytics)
data(edhec)
Returns = Return.Okunev(edhec[,1])
skewness(edhec[,1])
skewness(Returns)
# Right Shift of Returns Ditribution for a negative skewed distribution 
kurtosis(edhec[,1])
kurtosis(Returns)
# Reduction in "peakedness" around the mean
layout(rbind(c(1, 2), c(3, 4)))
 chart.Histogram(Returns, main = "Plain", methods = NULL)
 chart.Histogram(Returns, main = "Density", breaks = 40,
 methods = c("add.density", "add.normal"))
 chart.Histogram(Returns, main = "Skew and Kurt",
 methods = c("add.centered", "add.rug"))
chart.Histogram(Returns, main = "Risk Measures",
 methods = c("add.risk"))


###################################################
### code chunk number 4: Non-iid-OkunevWhite.Rnw:120-132
###################################################
library(PerformanceAnalytics)
data(edhec)
Returns = Return.Okunev(edhec[,1])
layout(rbind(c(1, 2), c(3, 4)))
 chart.Histogram(edhec[,1], main = "Plain", methods = NULL)
 chart.Histogram(edhec[,1], main = "Density", breaks = 40,
 methods = c("add.density", "add.normal"))
 chart.Histogram(edhec[,1], main = "Skew and Kurt",
 methods = c("add.centered", "add.rug"))
chart.Histogram(edhec[,1], main = "Risk Measures",
 methods = c("add.risk"))



