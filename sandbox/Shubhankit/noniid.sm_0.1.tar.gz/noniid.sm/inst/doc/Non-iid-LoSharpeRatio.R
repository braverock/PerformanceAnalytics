### R code from vignette source 'Non-iid-LoSharpeRatio.Rnw'

###################################################
### code chunk number 1: Non-iid-LoSharpeRatio.Rnw:52-55
###################################################
library(PerformanceAnalytics)
library(noniid.sm)
data(edhec)


###################################################
### code chunk number 2: Non-iid-LoSharpeRatio.Rnw:109-112
###################################################
library(PerformanceAnalytics)
data(edhec)
LoSharpe(edhec)


