### R code from vignette source 'Non-iid-ACFSTDEV.rnw'

###################################################
### code chunk number 1: Non-iid-ACFSTDEV.rnw:46-48
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-ACFSTDEV.rnw:51-52
###################################################
require(noniid.sm) #source('C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/ACStdDev.annualized.R')


###################################################
### code chunk number 3: Non-iid-ACFSTDEV.rnw:75-85
###################################################
library(PerformanceAnalytics)
data(edhec)
ACFVol = ACStdDev.annualized(edhec[,1:3])
Vol = StdDev.annualized(edhec[,1:3])
Vol
ACFVol
barplot(rbind(ACFVol,Vol), main="ACF and Orignal Volatility",
         xlab="Fund Type",ylab="Volatilty (in %)", col=c("darkblue","red"), beside=TRUE)
   legend("topright", c("1","2"), cex=0.6, 
                   bty="2", fill=c("darkblue","red"));


