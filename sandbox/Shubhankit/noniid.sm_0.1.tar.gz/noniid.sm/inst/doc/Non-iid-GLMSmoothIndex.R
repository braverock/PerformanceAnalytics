### R code from vignette source 'Non-iid-GLMSmoothIndex.Rnw'

###################################################
### code chunk number 1: Non-iid-GLMSmoothIndex.Rnw:46-48
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-GLMSmoothIndex.Rnw:51-52
###################################################
require(noniid.sm) #source('C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/GLMSmoothIndex.R')


###################################################
### code chunk number 3: Non-iid-GLMSmoothIndex.Rnw:100-103
###################################################
library(PerformanceAnalytics)
data(edhec)
GLMSmoothIndex(edhec)


