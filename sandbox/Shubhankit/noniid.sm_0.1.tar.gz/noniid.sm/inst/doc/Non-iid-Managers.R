### R code from vignette source 'Non-iid-Managers.Rnw'

###################################################
### code chunk number 1: Non-iid-Managers.Rnw:48-51
###################################################
library(PerformanceAnalytics)
library(noniid.sm)
data(edhec)


###################################################
### code chunk number 2: Non-iid-Managers.Rnw:82-84
###################################################
data(managers)
charts.PerformanceSummary(managers[,1:6],colorset = rich6equal, lwd = 2, ylog = TRUE)


###################################################
### code chunk number 3: Non-iid-Managers.Rnw:93-94
###################################################
table.Stats(managers[,1:6], ci = 0.95, digits = 4)


###################################################
### code chunk number 4: Non-iid-Managers.Rnw:100-101
###################################################
table.DownsideRisk(managers[,1:6], ci = 0.95, digits = 4)


###################################################
### code chunk number 5: Non-iid-Managers.Rnw:120-126
###################################################
ACFVol = ACStdDev.annualized(managers[,1:6])
Vol = StdDev.annualized(managers[,1:6])
barplot(rbind(ACFVol,Vol), main="ACF and Orignal Volatility",
         xlab="Fund Type",ylab="Volatilty (in %)", col=rich6equal[2:3], beside=TRUE)
   legend("topright", c("ACF","Orignal"), cex=0.6, 
                   bty="2", fill=rich6equal[2:3]);


###################################################
### code chunk number 6: Non-iid-Managers.Rnw:161-167
###################################################
Lo.Sharpe = LoSharpe(managers[,1:6])
Theoretical.Sharpe= SharpeRatio.annualized(managers[,1:6])
barplot(rbind(Theoretical.Sharpe,Lo.Sharpe), main="Sharpe Ratio Observed",
         xlab="Fund Type",ylab="Value", col=rich6equal[2:3], beside=TRUE)
   legend("topright", c("Orginal","Lo"), cex=0.6, 
                   bty="2", fill=rich6equal[2:3]);


###################################################
### code chunk number 7: Non-iid-Managers.Rnw:186-188
###################################################
round(CalmarRatio.Norm(managers[,1:6],1),4)
round(SterlingRatio.Norm(managers[,1:6],1),4)


###################################################
### code chunk number 8: Non-iid-Managers.Rnw:199-204
###################################################
library(noniid.sm)
source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/GLMSmoothIndex.R")
GLM.index=GLMSmoothIndex(managers[,1:6])
barplot(as.matrix(GLM.index), main="GLM Smooth Index",
         xlab="Fund Type",ylab="Value",colorset = rich6equal[1], beside=TRUE)


###################################################
### code chunk number 9: Non-iid-Managers.Rnw:233-235
###################################################
source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/AcarSim.R")
AcarSim(managers[,1:6])


###################################################
### code chunk number 10: Non-iid-Managers.Rnw:240-242
###################################################
library(noniid.sm)
chart.Autocorrelation(managers[,1:6])


###################################################
### code chunk number 11: Non-iid-Managers.Rnw:252-253
###################################################
charts.PerformanceSummary(managers[,1:6],colorset = rich6equal, lwd = 2, ylog = TRUE)


