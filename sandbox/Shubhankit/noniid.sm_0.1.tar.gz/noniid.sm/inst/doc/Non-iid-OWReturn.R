### R code from vignette source 'Non-iid-OWReturn.Rnw'

###################################################
### code chunk number 1: Non-iid-OWReturn.Rnw:48-50
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-OWReturn.Rnw:53-54
###################################################
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/Return.Okunev.R")


###################################################
### code chunk number 3: Non-iid-OWReturn.Rnw:102-105
###################################################
data(edhec)

charts.PerformanceSummary(edhec[1:132,],colorset = rich6equal, lwd = 2, ylog = TRUE)


###################################################
### code chunk number 4: Non-iid-OWReturn.Rnw:110-113
###################################################
data(edhec)

charts.PerformanceSummary(Return.Okunev(edhec[1:132,]),colorset = rich6equal, lwd = 2, ylog = TRUE)


###################################################
### code chunk number 5: Non-iid-OWReturn.Rnw:119-121
###################################################
data(edhec)
chart.Autocorrelation(edhec[,1:3])


###################################################
### code chunk number 6: Non-iid-OWReturn.Rnw:127-129
###################################################
data(edhec)
chart.Autocorrelation(Return.Okunev(edhec[,1:3]))


###################################################
### code chunk number 7: Non-iid-OWReturn.Rnw:137-154
###################################################
library(PerformanceAnalytics)
data(edhec)
Returns = Return.Okunev(edhec[,1])
skewness(edhec[,1])
skewness(Returns)
# Right Shift of Returns Ditribution for a negative skewed distribution 
kurtosis(edhec[,1])
kurtosis(Returns)
# Reduction in "peakedness" around the mean
layout(rbind(c(1, 2), c(3, 4)))
 chart.Histogram(Returns, main = "Plain", methods = NULL)
 chart.Histogram(Returns, main = "Density", breaks = 40,
 methods = c("add.density", "add.normal"))
 chart.Histogram(Returns, main = "Skew and Kurt",
 methods = c("add.centered", "add.rug"))
chart.Histogram(Returns, main = "Risk Measures",
 methods = c("add.risk"))


###################################################
### code chunk number 8: Non-iid-OWReturn.Rnw:158-170
###################################################
library(PerformanceAnalytics)
data(edhec)
Returns = Return.Okunev(edhec[,1])
layout(rbind(c(1, 2), c(3, 4)))
 chart.Histogram(edhec[,1], main = "Plain", methods = NULL)
 chart.Histogram(edhec[,1], main = "Density", breaks = 40,
 methods = c("add.density", "add.normal"))
 chart.Histogram(edhec[,1], main = "Skew and Kurt",
 methods = c("add.centered", "add.rug"))
chart.Histogram(edhec[,1], main = "Risk Measures",
 methods = c("add.risk"))



###################################################
### code chunk number 9: Non-iid-OWReturn.Rnw:183-187
###################################################
data(edhec)
t1=MeanAbsoluteDeviation(edhec[,1:3])
t2=MeanAbsoluteDeviation(Return.Okunev(edhec[,1:3])) 
((t2-t1)*100)/(t1) # % Change


###################################################
### code chunk number 10: Non-iid-OWReturn.Rnw:196-198
###################################################
data(portfolio_bacon)
print(Frequency(portfolio_bacon[,1])) #expected 12


###################################################
### code chunk number 11: Non-iid-OWReturn.Rnw:207-209
###################################################
data(managers)
SharpeRatio(managers[,1,drop=FALSE], Rf=.035/12, FUN="StdDev") 


###################################################
### code chunk number 12: Non-iid-OWReturn.Rnw:220-222
###################################################
data(portfolio_bacon)
print(MSquared(portfolio_bacon[,1], portfolio_bacon[,2])) #expected 0.1068


###################################################
### code chunk number 13: Non-iid-OWReturn.Rnw:234-237
###################################################
data(portfolio_bacon)
print(MSquaredExcess(portfolio_bacon[,1], portfolio_bacon[,2])) #expected -0.00998
print(MSquaredExcess(portfolio_bacon[,1], portfolio_bacon[,2], Method="arithmetic")) #expected -0.011


###################################################
### code chunk number 14: Non-iid-OWReturn.Rnw:247-251
###################################################
data(edhec)
table1 = table.DownsideRisk(edhec[,2:3])
table2 = table.DownsideRisk(Return.Okunev(edhec[,2:3]))
((abs(table2)-abs(table1))/(abs(table1)))*100


