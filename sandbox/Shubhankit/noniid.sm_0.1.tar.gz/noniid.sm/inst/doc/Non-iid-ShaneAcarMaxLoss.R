### R code from vignette source 'Non-iid-ShaneAcarMaxLoss.Rnw'

###################################################
### code chunk number 1: Non-iid-ShaneAcarMaxLoss.Rnw:49-51
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-ShaneAcarMaxLoss.Rnw:54-55
###################################################
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/AcarSim.R")


###################################################
### code chunk number 3: Non-iid-ShaneAcarMaxLoss.Rnw:79-82
###################################################
library(PerformanceAnalytics)
data(edhec)
chart.AcarSim(edhec)


