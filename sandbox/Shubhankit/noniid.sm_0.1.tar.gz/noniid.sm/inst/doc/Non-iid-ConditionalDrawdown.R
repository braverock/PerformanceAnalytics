### R code from vignette source 'Non-iid-ConditionalDrawdown.Rnw'

###################################################
### code chunk number 1: Non-iid-ConditionalDrawdown.Rnw:47-49
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-ConditionalDrawdown.Rnw:52-53
###################################################
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/CDrawdown.R")


###################################################
### code chunk number 3: Non-iid-ConditionalDrawdown.Rnw:77-80
###################################################
library(PerformanceAnalytics)
data(edhec)
CDrawdown(edhec)


