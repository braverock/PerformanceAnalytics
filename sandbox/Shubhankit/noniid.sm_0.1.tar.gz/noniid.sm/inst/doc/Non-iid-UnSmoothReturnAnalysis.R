### R code from vignette source 'Non-iid-UnSmoothReturnAnalysis.Rnw'

###################################################
### code chunk number 1: Non-iid-UnSmoothReturnAnalysis.Rnw:48-50
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-UnSmoothReturnAnalysis.Rnw:53-54
###################################################
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/Return.Okunev.R")


###################################################
### code chunk number 3: Non-iid-UnSmoothReturnAnalysis.Rnw:102-105
###################################################
data(edhec)

charts.PerformanceSummary(edhec[1:132,],colorset = rich6equal, lwd = 2, ylog = TRUE)


###################################################
### code chunk number 4: Non-iid-UnSmoothReturnAnalysis.Rnw:110-113
###################################################
data(edhec)

charts.PerformanceSummary(Return.Okunev(edhec[1:132,]),colorset = rich6equal, lwd = 2, ylog = TRUE)


###################################################
### code chunk number 5: Non-iid-UnSmoothReturnAnalysis.Rnw:119-121
###################################################
data(edhec)
chart.Autocorrelation(edhec[,1:3])


###################################################
### code chunk number 6: Non-iid-UnSmoothReturnAnalysis.Rnw:127-129
###################################################
data(edhec)
chart.Autocorrelation(Return.Okunev(edhec[,1:3]))


###################################################
### code chunk number 7: Non-iid-UnSmoothReturnAnalysis.Rnw:137-154
###################################################
library(PerformanceAnalytics)
data(edhec)
Returns = Return.Okunev(edhec[,1])
skewness(edhec[,1])
skewness(Returns)
# Right Shift of Returns Ditribution for a negative skewed distribution 
kurtosis(edhec[,1])
kurtosis(Returns)
# Reduction in "peakedness" around the mean
layout(rbind(c(1, 2), c(3, 4)))
 chart.Histogram(Returns, main = "Plain", methods = NULL)
 chart.Histogram(Returns, main = "Density", breaks = 40,
 methods = c("add.density", "add.normal"))
 chart.Histogram(Returns, main = "Skew and Kurt",
 methods = c("add.centered", "add.rug"))
chart.Histogram(Returns, main = "Risk Measures",
 methods = c("add.risk"))


###################################################
### code chunk number 8: Non-iid-UnSmoothReturnAnalysis.Rnw:158-170
###################################################
library(PerformanceAnalytics)
data(edhec)
Returns = Return.Okunev(edhec[,1])
layout(rbind(c(1, 2), c(3, 4)))
 chart.Histogram(edhec[,1], main = "Plain", methods = NULL)
 chart.Histogram(edhec[,1], main = "Density", breaks = 40,
 methods = c("add.density", "add.normal"))
 chart.Histogram(edhec[,1], main = "Skew and Kurt",
 methods = c("add.centered", "add.rug"))
chart.Histogram(edhec[,1], main = "Risk Measures",
 methods = c("add.risk"))



###################################################
### code chunk number 9: Non-iid-UnSmoothReturnAnalysis.Rnw:183-187
###################################################
data(edhec)
t1=MeanAbsoluteDeviation(edhec[,1:3])
t2=MeanAbsoluteDeviation(Return.Okunev(edhec[,1:3])) 
((t2-t1)*100)/(t1) # % Change


###################################################
### code chunk number 10: Non-iid-UnSmoothReturnAnalysis.Rnw:199-201
###################################################
SharpeRatio(edhec[,1:3,drop=FALSE]) 
SharpeRatio(Return.Okunev(edhec[,1:3,drop=FALSE])) 


###################################################
### code chunk number 11: Non-iid-UnSmoothReturnAnalysis.Rnw:214-217
###################################################
data(edhec)
VaR(edhec, p=.95, method="gaussian")
VaR(Return.Okunev(edhec), p=.95, method="gaussian") 


###################################################
### code chunk number 12: Non-iid-UnSmoothReturnAnalysis.Rnw:230-233
###################################################
data(managers)
CAPM.alpha(edhec, managers[,8,drop=FALSE], Rf=.035/12)
CAPM.alpha(Return.Okunev(edhec), managers[,8,drop=FALSE], Rf=.035/12)


###################################################
### code chunk number 13: Non-iid-UnSmoothReturnAnalysis.Rnw:240-243
###################################################
data(managers)
CAPM.beta(edhec, managers[, "SP500 TR", drop=FALSE], Rf = managers[, "US 3m TR", drop=FALSE])
CAPM.beta(Return.Okunev(edhec), managers[, "SP500 TR", drop=FALSE], Rf = managers[, "US 3m TR", drop=FALSE])


###################################################
### code chunk number 14: Non-iid-UnSmoothReturnAnalysis.Rnw:257-260
###################################################
data(edhec)
CAPM.jensenAlpha(edhec,managers[,8],Rf=.03/12)
CAPM.jensenAlpha(Return.Okunev(edhec),managers[,8],Rf=.03/12)


###################################################
### code chunk number 15: Non-iid-UnSmoothReturnAnalysis.Rnw:272-276
###################################################
data(edhec)
t1=SystematicRisk(edhec,managers[,8])
t2=SystematicRisk(Return.Okunev(edhec),managers[,8])
((abs(t2)-abs(t1))/(abs(t1)))*100


###################################################
### code chunk number 16: Non-iid-UnSmoothReturnAnalysis.Rnw:288-291
###################################################
data(managers)
round(TreynorRatio(edhec[,,drop=FALSE], managers[,8,drop=FALSE], Rf=.035/12),4)
round(TreynorRatio(Return.Okunev(edhec[,,drop=FALSE]), managers[,8,drop=FALSE], Rf=.035/12),4)


###################################################
### code chunk number 17: Non-iid-UnSmoothReturnAnalysis.Rnw:302-306
###################################################
data(edhec)
table1 = table.DownsideRisk(edhec[,2:3])
table2 = table.DownsideRisk(Return.Okunev(edhec[,2:3]))
((abs(table2)-abs(table1))/(abs(table1)))*100


###################################################
### code chunk number 18: Non-iid-UnSmoothReturnAnalysis.Rnw:319-322
###################################################
data(managers)
TrackingError(edhec, managers[,8,drop=FALSE]) 
TrackingError(Return.Okunev(edhec), managers[,8,drop=FALSE]) 


###################################################
### code chunk number 19: Non-iid-UnSmoothReturnAnalysis.Rnw:333-336
###################################################
data(managers)
InformationRatio(edhec, managers[,8,drop=FALSE]) 
abs(InformationRatio(Return.Okunev(edhec), managers[,8,drop=FALSE])) 


###################################################
### code chunk number 20: Non-iid-UnSmoothReturnAnalysis.Rnw:351-354
###################################################
data(edhec)
print(PainIndex(edhec[,]))
print(PainIndex(Return.Okunev(edhec[,])))


###################################################
### code chunk number 21: Non-iid-UnSmoothReturnAnalysis.Rnw:361-364
###################################################
data(managers)
CalmarRatio(edhec)
CalmarRatio(Return.Okunev(edhec))


###################################################
### code chunk number 22: Non-iid-UnSmoothReturnAnalysis.Rnw:371-374
###################################################
data(managers)
SterlingRatio(edhec)
SterlingRatio(Return.Okunev(edhec))


###################################################
### code chunk number 23: Non-iid-UnSmoothReturnAnalysis.Rnw:385-388
###################################################
data(edhec)
(BurkeRatio(edhec)) 
BurkeRatio(Return.Okunev(edhec))


###################################################
### code chunk number 24: Non-iid-UnSmoothReturnAnalysis.Rnw:399-402
###################################################
data(edhec)
BurkeRatio(edhec)
BurkeRatio(Return.Okunev(edhec))


###################################################
### code chunk number 25: Non-iid-UnSmoothReturnAnalysis.Rnw:413-416
###################################################
data(edhec)
MartinRatio(edhec) #expected 1.70
MartinRatio(Return.Okunev(edhec))


###################################################
### code chunk number 26: Non-iid-UnSmoothReturnAnalysis.Rnw:427-430
###################################################
data(edhec)
PainRatio(edhec)
PainRatio(Return.Okunev(edhec))


###################################################
### code chunk number 27: Graph3
###################################################
chart.RiskReturnScatter(edhec[117:152,1:8], Rf=.03/12, main = "Trailing 36-Month Performance", colorset=c("red", rep("black",5), "orange", "green"))


###################################################
### code chunk number 28: Graph4
###################################################
chart.RiskReturnScatter(Return.Okunev(edhec[117:152,1:8]), Rf=.03/12, main = "Trailing 36-Month Performance", colorset=c("red", rep("black",5), "orange", "green"))


###################################################
### code chunk number 29: Graph5
###################################################
charts.RollingPerformance(edhec[,1:4], Rf=.03/12, colorset = rich6equal, lwd = 2)


###################################################
### code chunk number 30: Graph6
###################################################
charts.RollingPerformance(Return.Okunev(edhec[,1:4]), Rf=.03/12, colorset = rich6equal, lwd = 2)


