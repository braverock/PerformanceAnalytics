### R code from vignette source 'Non-iid-NormCalmar-Sterling.rnw'

###################################################
### code chunk number 1: Non-iid-NormCalmar-Sterling.rnw:49-51
###################################################
library(PerformanceAnalytics)
data(edhec)


###################################################
### code chunk number 2: Non-iid-NormCalmar-Sterling.rnw:54-57
###################################################
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/CalmarRatio.Norm.R")
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/SterlingRatio.Norm.R")
require(noniid.sm) #source("C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/QP.Norm.R")


###################################################
### code chunk number 3: Non-iid-NormCalmar-Sterling.rnw:102-106
###################################################
library(PerformanceAnalytics)
data(edhec)
CalmarRatio.Norm(edhec,1)
SterlingRatio.Norm(edhec,1)


