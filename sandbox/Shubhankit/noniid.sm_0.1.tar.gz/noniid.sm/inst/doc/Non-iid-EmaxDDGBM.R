### R code from vignette source 'Non-iid-EmaxDDGBM.Rnw'

###################################################
### code chunk number 1: Non-iid-EmaxDDGBM.Rnw:48-49
###################################################
require(noniid.sm) #source('C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/LoSharpe.R')


###################################################
### code chunk number 2: Non-iid-EmaxDDGBM.Rnw:52-55
###################################################
library(PerformanceAnalytics)
data(edhec)
data(managers)


###################################################
### code chunk number 3: Non-iid-EmaxDDGBM.Rnw:76-84
###################################################
source('C:/Users/shubhankit/Desktop/Again/pkg/PerformanceAnalytics/sandbox/Shubhankit/noniid.sm/R/EmaxDDGBM.R')
data(edhec)
Lo.Sharpe = -100*ES(edhec,.99)
Theoretical.Sharpe= EmaxDDGBM(edhec)
barplot(as.matrix(rbind(Theoretical.Sharpe,Lo.Sharpe)), main="Expected Shortfall(.99) and Drawdown of a Brwonian Motion Asset Process",
         xlab="Fund Type",ylab="Value", col=rich6equal[1:2], beside=TRUE)
   legend("topright", c("ES","EGBMDD"), cex=0.6, 
                   bty="2", fill=rich6equal[1:2]);


###################################################
### code chunk number 4: Non-iid-EmaxDDGBM.Rnw:89-97
###################################################

data(managers)
Lo.Sharpe = -100*ES(managers[,1:6],.99)
Theoretical.Sharpe= EmaxDDGBM(managers[,1:6])
barplot(as.matrix(rbind(Theoretical.Sharpe,Lo.Sharpe)), main="Expected Shortfall(.99) and Drawdown of a Brwonian Motion Asset Process",
         xlab="Fund Type",ylab="Value", col=rich6equal[1:2], beside=TRUE)
   legend("topright", c("ES","EGBMDD"), cex=0.6, 
                   bty="2", fill=rich6equal[1:2]);


